package com.tian.guided3_stringextra

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class GD3StringExtra1 : AppCompatActivity() {

    private lateinit var etAngka : TextInputEditText
    private var btnRGrup : RadioGroup? = null
    private lateinit var btnRButton : RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun sendMessage(view: View){
        val intent = Intent(this, DisplayMessage::class.java)
        val message: String
        btnRGrup = findViewById(R.id.radioGroup)
        val angka: Int = (etAngka.txt.toString()).toInt()

        intent.putExtra("inputAngka",angka.toString())
        startActivity(intent)
    }

    companion object{
        const val EXTRA_MESSAGE = "MESSAGE"
    }
}